---
name: car-nav
description: Control BYD car navigation via Map Protocol SDK - navigate to destination, home, office, cancel
tools:
  - bash
---

# Car Navigation Control (BYD Map SDK)

通过 BYD 地图 Protocol SDK 控制车机导航。回复简短自然，适合语音播报。

## 规则
- 收到导航指令必须先回复用户"好的，正在为您导航"，然后再执行操作
- 禁止使用高德地图（com.autonavi.minimap）和 Google Maps
- 禁止自己编造命令，只使用本文件列出的命令
- **所有操作通过 HTTP API /map/* 端点执行**
- 导航启动需要约10秒，请告知用户"导航即将开始"
- **两步导航流程**：先搜索返回结果给用户选择，再导航到选择的目的地

## HTTP API 调用方式

本设备没有 curl，使用 node 发请求：
```bash
api() { LD_LIBRARY_PATH=/data/local/tmp/node-lib OPENSL_CONF=/data/local/tmp/node-lib/openssl.cnf /data/local/tmp/node-termux -e 'const http=require("http"),d=process.argv[1],o=JSON.parse(process.argv[2]||"{}"),r=http.request({hostname:"127.0.0.1",port:18802,path:d,method:"POST",headers:{"Content-Type":"application/json",Connection:"close"},timeout:45000},res=>{let b="";res.on("data",c=>b+=c);res.on("end",()=>console.log(b))});r.write(JSON.stringify(o));r.end()' "$1" "$2"; }
```

## 可用端点

| 路径 | JSON 参数 | 说明 |
|------|-----------|------|
| `/map/searchPoi` | `{"keyword":"目的地"}` | 搜索POI并返回名称列表（推荐） |
| `/map/select` | `{"index":1}` | 选择第N个搜索结果并开始导航 |
| `/map/navi` | `{"keyword":"目的地","index":1}` | 一步搜索+自动选择第N个结果导航 |
| `/map/home` | `{}` | 导航回家 |
| `/map/office` | `{}` | 导航去公司 |
| `/map/cancel` | `{}` | 取消当前导航（立即返回，异步生效） |
| `/map/naviState` | `{}` | 查询导航状态 |

## 导航流程（推荐两步）

### 第一步：搜索

将 DEST 替换为实际地名（如"加油站"、"肯德基"、"万达广场"）：
```bash
api() { LD_LIBRARY_PATH=/data/local/tmp/node-lib OPENSSL_CONF=/data/local/tmp/node-lib/openssl.cnf /data/local/tmp/node-termux -e 'const http=require("http"),d=process.argv[1],o=JSON.parse(process.argv[2]||"{}"),r=http.request({hostname:"127.0.0.1",port:18802,path:d,method:"POST",headers:{"Content-Type":"application/json",Connection:"close"},timeout:45000},res=>{let b="";res.on("data",c=>b+=c);res.on("end",()=>console.log(b))});r.write(JSON.stringify(o));r.end()' "$1" "$2"; }
api /map/searchPoi '{"keyword":"DEST"}'
```

成功返回：`{"ok":true,"count":5,"poi_list":["中国石化坪山加油站","中国石化燕子岭加油站",...]}`

将结果读给用户，让用户选择。

### 第二步：选择并导航

将 N 替换为用户选择的结果编号（从1开始）：
```bash
api() { LD_LIBRARY_PATH=/data/local/tmp/node-lib OPENSSL_CONF=/data/local/tmp/node-lib/openssl.cnf /data/local/tmp/node-termux -e 'const http=require("http"),d=process.argv[1],o=JSON.parse(process.argv[2]||"{}"),r=http.request({hostname:"127.0.0.1",port:18802,path:d,method:"POST",headers:{"Content-Type":"application/json",Connection:"close"},timeout:45000},res=>{let b="";res.on("data",c=>b+=c);res.on("end",()=>console.log(b))});r.write(JSON.stringify(o));r.end()' "$1" "$2"; }
api /map/select '{"index":N}'
```

成功返回：`{"ok":true,"result":"好的"}` → 导航即将开始

## 快捷导航（直接导航，不显示搜索结果）

### 一步导航（搜索+自动选择第一个结果）
```bash
api() { LD_LIBRARY_PATH=/data/local/tmp/node-lib OPENSSL_CONF=/data/local/tmp/node-lib/openssl.cnf /data/local/tmp/node-termux -e 'const http=require("http"),d=process.argv[1],o=JSON.parse(process.argv[2]||"{}"),r=http.request({hostname:"127.0.0.1",port:18802,path:d,method:"POST",headers:{"Content-Type":"application/json",Connection:"close"},timeout:45000},res=>{let b="";res.on("data",c=>b+=c);res.on("end",()=>console.log(b))});r.write(JSON.stringify(o));r.end()' "$1" "$2"; }
api /map/navi '{"keyword":"DEST","index":1}'
```

### 回家
```bash
api() { LD_LIBRARY_PATH=/data/local/tmp/node-lib OPENSL_CONF=/data/local/tmp/node-lib/openssl.cnf /data/local/tmp/node-termux -e 'const http=require("http"),d=process.argv[1],o=JSON.parse(process.argv[2]||"{}"),r=http.request({hostname:"127.0.0.1",port:18802,path:d,method:"POST",headers:{"Content-Type":"application/json",Connection:"close"},timeout:45000},res=>{let b="";res.on("data",c=>b+=c);res.on("end",()=>console.log(b))});r.write(JSON.stringify(o));r.end()' "$1" "$2"; }
api /map/home '{}'
```

### 去公司
```bash
api() { LD_LIBRARY_PATH=/data/local/tmp/node-lib OPENSL_CONF=/data/local/tmp/node-lib/openssl.cnf /data/local/tmp/node-termux -e 'const http=require("http"),d=process.argv[1],o=JSON.parse(process.argv[2]||"{}"),r=http.request({hostname:"127.0.0.1",port:18802,path:d,method:"POST",headers:{"Content-Type":"application/json",Connection:"close"},timeout:45000},res=>{let b="";res.on("data",c=>b+=c);res.on("end",()=>console.log(b))});r.write(JSON.stringify(o));r.end()' "$1" "$2"; }
api /map/office '{}'
```

## 取消导航
```bash
api() { LD_LIBRARY_PATH=/data/local/tmp/node-lib OPENSL_CONF=/data/local/tmp/node-lib/openssl.cnf /data/local/tmp/node-termux -e 'const http=require("http"),d=process.argv[1],o=JSON.parse(process.argv[2]||"{}"),r=http.request({hostname:"127.0.0.1",port:18802,path:d,method:"POST",headers:{"Content-Type":"application/json",Connection:"close"},timeout:45000},res=>{let b="";res.on("data",c=>b+=c);res.on("end",()=>console.log(b))});r.write(JSON.stringify(o));r.end()' "$1" "$2"; }
api /map/cancel '{}'
```
取消命令立即返回，实际取消需要几秒钟生效。

## 查询导航状态
```bash
api() { LD_LIBRARY_PATH=/data/local/tmp/node-lib OPENSL_CONF=/data/local/tmp/node-lib/openssl.cnf /data/local/tmp/node-termux -e 'const http=require("http"),d=process.argv[1],o=JSON.parse(process.argv[2]||"{}"),r=http.request({hostname:"127.0.0.1",port:18802,path:d,method:"POST",headers:{"Content-Type":"application/json",Connection:"close"},timeout:45000},res=>{let b="";res.on("data",c=>b+=c);res.on("end",()=>console.log(b))});r.write(JSON.stringify(o));r.end()' "$1" "$2"; }
api /map/naviState '{}'
```
